module.exports.categoriesController=require("./categories.controllers")
module.exports.subcategoriesController=require("./subcategories.controller")
module.exports.productsController=require("./products.controller")

