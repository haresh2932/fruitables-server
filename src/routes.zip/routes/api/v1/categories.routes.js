const express = require('express');
const { categoriesController } = require('../../../controller');
const router = express.Router()

router.get(
    "/list-categories",
    categoriesController.listCategories
)

router.get(
    "/list-categories/:category_id",
    categoriesController.getCategory
)
router.post(
    "/add-category",
    categoriesController.addCategory
)

router.put(
    "/update-category/:category_id",
    categoriesController.updateCategory
)

router.delete(
    "/delete-category/:category_id",
    categoriesController.deleteCategory
)

router.get(
    "/count-subcategories",
    categoriesController.getSubcategory    
)

router.get(
    "/inactive",
    categoriesController.getInactiveCategory
)




module.exports=router